#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define BUF_SIZE 512

// 💡 공통 요청 수신 함수
int receiveRequest(int sock, char *buf, size_t size) {
    memset(buf, 0, size);
    int len = recv(sock, buf, size - 1, 0);
    if (len > 0) buf[len] = '\0';
    return len;
}

// 💡 공통 응답 전송 함수
void sendResponse(int sock, const char *msg) {
    char buf[BUF_SIZE];
    memset(buf, 0, sizeof(buf));
    snprintf(buf, sizeof(buf), "%s", msg);
    send(sock, buf, strlen(buf), 0);
}

// 💡 식단 입력 처리
void handleInputMeal(const char *data, char *response) {
    char food[50];
    float gram;
    sscanf(data, "%[^/]/%f", food, &gram);
    snprintf(response, BUF_SIZE, "✅ 입력된 음식: %s, 섭취량: %.1fg (DB 저장됨)", food, gram);
}

// 💡 운동 입력 처리
void handleInputWorkout(const char *data, char *response) {
    char workout[50];
    float hour;
    sscanf(data, "%[^/]/%f", workout, &hour);
    snprintf(response, BUF_SIZE, "✅ 입력된 운동: %s, 시간: %.1fh (DB 저장됨)", workout, hour);
}

// 💡 날짜별 기록 조회 처리
void handleGetRecord(char *response) {
    snprintf(response, BUF_SIZE,
             "MEAL:사과 100g|바나나 200g#WORKOUT:달리기 30분|걷기 20분#WEIGHT:70kg");
}

// 💡 진행률 조회 처리
void handleProgress(char *response) {
    snprintf(response, BUF_SIZE,
             "progress:25.0|initialWeight:80.0|goalWeight:60.0|currentWeight:70.0");
}

// 💡 클라이언트 요청 처리
void processRequest(int clientSock) {
    char recvBuf[BUF_SIZE];
    char sendBuf[BUF_SIZE];

    while (1) {
        int len = receiveRequest(clientSock, recvBuf, sizeof(recvBuf));
        if (len <= 0) break;

        printf("[서버] 받은 요청: %s\n", recvBuf);
        memset(sendBuf, 0, sizeof(sendBuf));

        if (strncmp(recvBuf, "INPUT_MEAL/", 11) == 0) {
            handleInputMeal(recvBuf + 11, sendBuf);
        }
        else if (strncmp(recvBuf, "INPUT_WORKOUT/", 14) == 0) {
            handleInputWorkout(recvBuf + 14, sendBuf);
        }
        else if (strncmp(recvBuf, "GET_RECORD", 10) == 0) {
            handleGetRecord(sendBuf);
        }
        else if (strncmp(recvBuf, "PROGRESS", 8) == 0) {
            handleProgress(sendBuf);
        }
        else if (strncmp(recvBuf, "LOGOUT", 6) == 0) {
            sendResponse(clientSock, "로그아웃 완료! 연결 종료.");
            break;
        }
        else {
            snprintf(sendBuf, BUF_SIZE, "❌ 잘못된 명령입니다.");
        }

        sendResponse(clientSock, sendBuf);
    }

    close(clientSock);
    printf("클라이언트 연결 종료.\n");
}

int main() {
    int servSock = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in servAddr = {0}, cliAddr = {0};
    servAddr.sin_family = AF_INET;
    servAddr.sin_port = htons(9000);
    servAddr.sin_addr.s_addr = INADDR_ANY;

    bind(servSock, (struct sockaddr*)&servAddr, sizeof(servAddr));
    listen(servSock, 5);
    printf("서버 시작! 클라이언트 접속 대기 중...\n");

    socklen_t cliSize = sizeof(cliAddr);
    int clientSock = accept(servSock, (struct sockaddr*)&cliAddr, &cliSize);

    processRequest(clientSock);

    close(servSock);
    printf("서버 종료.\n");
    return 0;
}