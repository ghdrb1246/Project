#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <curl/curl.h>
#include <json-c/json.h>

#define BUF_SIZE 1024

// 응답을 받을 버퍼에 덧붙이기 위한 콜백 함수
size_t write_callback(void *contents, size_t size, size_t nmemb, void *userp) {
    strcat((char*)userp, (char*)contents);
    return size * nmemb;
}

// 음식명 기반 외부 API 호출 및 JSON 파싱 (libcurl + json-c)
float getFoodKcalFromAPI(const char *foodName) {
    CURL *curl = curl_easy_init();
    if (!curl) return -1;

    // 예: "사과"를 URL 인코딩 (실제로는 curl_easy_escape 등 사용 가능)
    char url[512];
    snprintf(url, sizeof(url),
             "https://openapi.foodsafetykorea.go.kr/api/인증키/json/I2790/1/1/DESC_KOR=%%EC%%82%%AC%%EA%%B3%%BC");  // "사과" 예제

    // API 응답을 받을 버퍼
    char response[4096] = "";

    curl_easy_setopt(curl, CURLOPT_URL, url);
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write_callback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, response);
    curl_easy_perform(curl);
    curl_easy_cleanup(curl);

    // JSON 파싱
    struct json_object *root = json_tokener_parse(response);
    struct json_object *body, *items, *item, *kcalObj;
    float kcal = -1;

    if (json_object_object_get_ex(root, "I2790", &body) &&
        json_object_object_get_ex(body, "row", &items) &&
        json_object_array_length(items) > 0) {

        item = json_object_array_get_idx(items, 0);
        if (json_object_object_get_ex(item, "NUTR_CONT1", &kcalObj)) {
            const char *kcalStr = json_object_get_string(kcalObj);
            kcal = atof(kcalStr);
        }
    }

    json_object_put(root);  // 메모리 해제
    return kcal;
}

int main() {
    // 서버 소켓 준비
    int servSock = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in servAddr = {0}, cliAddr = {0};
    servAddr.sin_family = AF_INET;
    servAddr.sin_port = htons(9000);
    servAddr.sin_addr.s_addr = INADDR_ANY;
    bind(servSock, (struct sockaddr*)&servAddr, sizeof(servAddr));
    listen(servSock, 5);

    printf("서버 시작! 대기 중...\n");
    socklen_t cliSize = sizeof(cliAddr);
    int clientSock = accept(servSock, (struct sockaddr*)&cliAddr, &cliSize);

    while (1) {
        char recvBuf[BUF_SIZE];
        int len = recv(clientSock, recvBuf, sizeof(recvBuf)-1, 0);
        recvBuf[len] = '\0';
        printf("[서버] 음식명 요청: %s\n", recvBuf);

        // 외부 API 호출!
        float kcal = getFoodKcalFromAPI(recvBuf);
        if (kcal >= 0) {
            char response[64];
            snprintf(response, sizeof(response), "OK/%.1f", kcal);
            send(clientSock, response, strlen(response), 0);
            break;
        } else {
            send(clientSock, "NOT_FOUND", 9, 0);
        }
    }

    close(clientSock);
    close(servSock);
    return 0;
}
