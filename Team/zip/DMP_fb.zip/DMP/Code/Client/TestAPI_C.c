#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define BUF_SIZE 256

int main() {
    int sock = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in servAddr = {0};
    servAddr.sin_family = AF_INET;
    servAddr.sin_port = htons(9000);
    servAddr.sin_addr.s_addr = inet_addr("127.0.0.1");

    connect(sock, (struct sockaddr*)&servAddr, sizeof(servAddr));

    while (1) {
        char food[20];
        printf("음식명 입력: ");
        scanf("%s", food);

        send(sock, food, strlen(food), 0);

        char recvBuf[BUF_SIZE];
        int len = recv(sock, recvBuf, sizeof(recvBuf)-1, 0);
        recvBuf[len] = '\0';

        if (strncmp(recvBuf, "OK/", 3) == 0) {
            float kcal;
            sscanf(recvBuf + 3, "%f", &kcal);
            printf("✅ %s의 칼로리: %.1fkcal\n", food, kcal);
            break;
        } else if (strcmp(recvBuf, "NOT_FOUND") == 0) {
            printf("❌ 음식 없음! 다시 입력하세요.\n");
        }
    }

    close(sock);
    return 0;
}