#ifndef _MS_
#define _MS_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "DBM.h"
#include "InputInfo.h"
#include "CsvDB.h"

#ifdef _WIN32
    #include <winsock2.h>
    #pragma comment(lib, "ws2_32.lib")
    typedef int socklen_t;
    #define CLOSESOCKET closesocket
#else
    #include <unistd.h>
    #include <arpa/inet.h>
    #include <sys/socket.h>
    #define SOCKET int
    #define CLOSESOCKET close
#endif

// 공통 요청 수신 함수
int receiveRequest(int sock, char *buf, size_t size);

// 공통 응답 전송 함수
void sendResponse(int sock, const char *msg);

// 클라이언트 요청 처리 루프
void handleClient(SOCKET clientSock);

// 클라이언트 요청 처리
void processRequest(SOCKET clientSock, char *request, char *response);

// 회원가입 처리
void handleInputSignup(const char *data, char *response);

// 로그인 처리
void handleInputLogin(const char *data, char *response);

// 식단 입력 처리
void handleInputMeal(const char *data, char *response);

// 운동 입력 처리
void handleInputWorkout(const char *data, char *response);

// 체중 입력 처리
void handleInputWeight(const char *data, char *response);

// 날짜별 기록 조회 처리
void handleGetRecord(const char *data, char *response);

// 감량 진행률 계산
void handleProgress(const char *data, char *response);

// 피드백 추천
void handleFeedback(const char *data, char *response);

// 로그아웃 처리
void handleLogout(const char *data);

// 회원 탈퇴 처리
void handleDeleteId(const char *data);

#endif