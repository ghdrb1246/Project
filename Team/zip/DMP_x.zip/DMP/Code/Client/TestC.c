#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define BUF_SIZE 512

typedef enum {
    STATE_MAIN_MENU,
    STATE_USER_MENU,
    STATE_EXIT
} State;

// 💡 공통 요청 함수
void sendRequest(int sock, const char *request) {
    send(sock, request, strlen(request), 0);
}

// 💡 공통 응답 함수
void receiveResponse(int sock, char *response, size_t size) {
    memset(response, 0, size);
    int len = recv(sock, response, size - 1, 0);
    response[len] = '\0';
}

// 💡 사용자 메뉴
void userMenu(int sock) {
    while (1) {
        printf("\n=== 사용자 메뉴 ===\n");
        printf("1. 식단 입력\n");
        printf("2. 운동 입력\n");
        printf("3. 날짜별 기록 조회\n");
        printf("4. 진행률 조회\n");
        printf("5. 로그아웃\n");
        printf("메뉴 선택: ");

        int choice;
        scanf("%d", &choice);

        char sendBuf[BUF_SIZE];
        char recvBuf[BUF_SIZE];

        if (choice == 1) {
            char food[50];
            float gram;
            printf("음식명 입력: ");
            scanf("%s", food);
            printf("섭취량(g) 입력: ");
            scanf("%f", &gram);
            snprintf(sendBuf, sizeof(sendBuf), "INPUT_MEAL/%s/%.1f", food, gram);
        }
        else if (choice == 2) {
            char workout[50];
            float hour;
            printf("운동명 입력: ");
            scanf("%s", workout);
            printf("운동 시간(h) 입력: ");
            scanf("%f", &hour);
            snprintf(sendBuf, sizeof(sendBuf), "INPUT_WORKOUT/%s/%.1f", workout, hour);
        }
        else if (choice == 3) {
            snprintf(sendBuf, sizeof(sendBuf), "GET_RECORD");
        }
        else if (choice == 4) {
            snprintf(sendBuf, sizeof(sendBuf), "PROGRESS");
        }
        else if (choice == 5) {
            snprintf(sendBuf, sizeof(sendBuf), "LOGOUT");
        }
        else {
            printf("❌ 잘못된 선택!\n");
            continue;
        }

        sendRequest(sock, sendBuf);
        receiveResponse(sock, recvBuf, sizeof(recvBuf));
        printf("== 서버 응답 ==\n%s\n", recvBuf);

        if (choice == 5) break;
    }
}

int main() {
    int sock = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in servAddr = {0};
    servAddr.sin_family = AF_INET;
    servAddr.sin_port = htons(9000);
    servAddr.sin_addr.s_addr = inet_addr("127.0.0.1");

    connect(sock, (struct sockaddr*)&servAddr, sizeof(servAddr));

    State currentState = STATE_MAIN_MENU;

    while (currentState != STATE_EXIT) {
        switch (currentState) {
            case STATE_MAIN_MENU:
                printf("\n=== 메인 메뉴 ===\n");
                printf("1. 로그인\n");
                printf("2. 프로그램 종료\n");
                printf("메뉴 선택: ");
                int choice;
                scanf("%d", &choice);

                if (choice == 1) {
                    printf("✅ 로그인 성공!\n");
                    currentState = STATE_USER_MENU;
                } else if (choice == 2) {
                    currentState = STATE_EXIT;
                } else {
                    printf("❌ 잘못된 선택!\n");
                }
                break;

            case STATE_USER_MENU:
                userMenu(sock);
                currentState = STATE_MAIN_MENU;  // 로그아웃 후 메인으로
                break;

            default:
                currentState = STATE_EXIT;
                break;
        }
    }

    close(sock);
    printf("프로그램 종료!\n");
    return 0;
}
