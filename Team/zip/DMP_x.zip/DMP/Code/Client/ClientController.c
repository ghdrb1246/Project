#include "ClientController.h"

/* void sendRequest(int sock, const char *message) {
    char recvBuf[BUF_SIZE];

    send(sock, message, strlen(message), 0);

    memset(recvBuf, 0, sizeof(recvBuf));
    int len = recv(sock, recvBuf, BUF_SIZE - 1, 0);

    if (len > 0) {
        recvBuf[len] = '\0';
        // printf("\n\n[응답] %s\n\n", recvBuf);
    }
} */

int sendRequestWithResponse(int sock, const char *message, char *response) {
    char recvBuf[BUF_SIZE];
    memset(recvBuf, 0, sizeof(recvBuf));

    sendRequest(sock, message);

    int len = recv(sock, recvBuf, BUF_SIZE - 1, 0);

    if (len > 0) {
        recvBuf[len] = '\0';
        strcpy(response, recvBuf);
        return 1;
    }

    return 0;
}

// 공통 요청 함수
void sendRequest(int sock, const char *request) {
    send(sock, request, strlen(request), 0);
}

// 공통 응답 함수
void receiveResponse(int sock, char *response, size_t size) {
    memset(response, 0, size);
    int len = recv(sock, response, size - 1, 0);
    response[len] = '\0';
}

MenuState handleMainMenu(int sock) {
    int meunNumber = mainMenu(), reu = -1, state_main_num = -1;
    char sendBuf[BUF_SIZE], id[ID_SIZE], pw[PW_SIZE], response[BUF_SIZE];

    UserSignupInfo *USI = USImalloc();
    
    switch (meunNumber) {
        case 1:
            signupMenu(USI);

            sprintf(
                sendBuf, 
                "SIGNUP/%s/%s/%s/%d/%f/%f/%f", 
                USI->id, USI->pw, USI->gender, USI->age,
                USI->height, USI->exerciseWeight, USI->goalWeight
            ); 
            reu = 1;
            state_main_num = STATE_MAIN_MENU;
        break;
        
        case 2:
            loginMenu(id, pw);

            sprintf(sendBuf, "LOGIN/%s/%s", id, pw);

            // memset(response, 0, sizeof(response));
            if (sendRequestWithResponse(sock, sendBuf, response)) {
                
                // 서버 응답에 \"성공\"이 포함되면
                if (strstr(response, "성공")) {
                    printf("성공\n");
                    strcpy(loggedInUserId, id);

                    state_main_num = STATE_USER_MENU;
                }
                else {
                    printf("실패\n");
                }
            }

            state_main_num = STATE_MAIN_MENU;
        break;

        case 3:
            printf("프로그램을 종료합니다.\n");
            state_main_num = STATE_EXIT;
        break;
        
        default:
            sprintf(sendBuf, "MENU/%d", meunNumber);
            reu = 1;
            state_main_num = STATE_MAIN_MENU;
        break;
    }

    sendRequest(sock, sendBuf);
    
    if (reu > -1) {
        receiveResponse(sock, response, sizeof(response));
    }

    USIfree(USI);

    return state_main_num;
}

MenuState handleUserMenu(int sock) {
    char id[ID_SIZE];
    char sendBuf[BUF_SIZE], recvBuf[BUF_SIZE], response[BUF_SIZE];
    char date[11] = "";
    
    strcpy(id, loggedInUserId);

    int choice = userMenu(id);
    int len, reu = -1, state_main_num = -1;

    MealInputInfo *MII = MIImalloc();
    WorkOutInputInfo *WOII = WOIImalloc();
    WeightInputInfo *WII = WIImalloc();

    switch (choice) {
        case 1: 
            while(1) {
                mealMenu(MII);

                sprintf(sendBuf, 
                    "INPUT_MEAL/%s/%s/%s/%f", 
                    id, MII->dateTime, MII->foodName, MII->gram
                );

                if (sendRequestWithResponse(sock, sendBuf, response)) {
                    // 서버 응답에 \"성공\"이 포함되면
                    if (strstr(response, "성공")) {
                        // printf("[응답] %s\n", response);
                        break;
                    }
                    else {
                        // printf("[응답] %s\n", response);
                        printf("%s 는/은 제공된 음식 파일에 입력 식단은 없습니다. 다시 입력 해주세요..\n", MII->foodName);
                    }
                }
            }
            state_main_num = STATE_USER_MENU;
        break;
        
        case 2: 
            while(1) {
                workOutMenu(WOII);

                sprintf(sendBuf, "INPUT_WORKOUT/%s/%s/%s/%f", id, WOII->dateTime, WOII->exerciseName, WOII->minutes);
                
                if (sendRequestWithResponse(sock, sendBuf, response)) {
                    // 서버 응답에 \"성공\"이 포함되면
                    if (strstr(response, "성공")) {
                        // printf("[응답] %s\n", response);
                        break;
                    }
                    else {
                        // printf("[응답] %s\n", response);
                        printf("%s 는/은 제공된 운동 파일에 입력 운동은 없습니다. 다시 입력 해주세요..\n", WOII->exerciseName);
                    }
                }
            }
            state_main_num = STATE_USER_MENU;
        break;
        
        case 3: 
            weightMenu(WII);

            sprintf(sendBuf, "INPUT_WEIGHT/%s/%s/%f", id, WII->date, WII->weight);
            sendRequest(sock, sendBuf);
            state_main_num = STATE_USER_MENU;
        break;
        
        case 4:
            snprintf(sendBuf, sizeof(sendBuf), "GET_RECORD/%s/%s", id, date);
            sendRequest(sock, sendBuf);

            receiveResponse(sock, recvBuf, sizeof(recvBuf) - 1);

            // printf("2CC : %s\n", recvBuf);
            viewRecordsByDate_OUT_Menu(recvBuf, date);
            
            // memset(sendBuf, 0, sizeof(sendBuf));
            // memset(recvBuf, 0, sizeof(recvBuf));
            state_main_num = STATE_USER_MENU;
        break;

        case 5: 
            sprintf(sendBuf, "CHECK_PROGRESS/%s", id); 
            sendRequest(sock, sendBuf);

            receiveResponse(sock, recvBuf, sizeof(recvBuf) - 1);

            checkWeightLossProgressMenu(recvBuf, id);
            
            // memset(sendBuf, 0, sizeof(sendBuf));
            // memset(recvBuf, 0, sizeof(recvBuf));
            state_main_num = STATE_USER_MENU;
        break;

        case 6: 
            sprintf(sendBuf, "FEEDBACK/%s", id); 
            sendRequest(sock, sendBuf);

            receiveResponse(sock, recvBuf, sizeof(recvBuf) - 1);

            feedBackMenu(60, 1000);
            
            // memset(sendBuf, 0, sizeof(sendBuf));
            // memset(recvBuf, 0, sizeof(recvBuf));
            state_main_num = STATE_USER_MENU;
        break;

        case 7: 
            sprintf(sendBuf, "LOGOUT/%s", id);
            strcpy(loggedInUserId, "");
            
            sendRequest(sock, sendBuf);
            
            // memset(sendBuf, 0, sizeof(sendBuf));
        
            state_main_num = STATE_MAIN_MENU;
        break;

        case 8: 
            deleteIdMenu(id);
            
            sprintf(sendBuf, "DELETE_ID/%s", id); 
            sendRequest(sock, sendBuf);

            // memset(sendBuf, 0, sizeof(sendBuf));
            state_main_num = STATE_USER_MENU;
        break;
        
        default:
            printf("잘못된 선택입니다.\n");
            state_main_num = STATE_MAIN_MENU;
        break;
    }

    // sendRequest(sock, sendBuf);
    
    MIIfree(MII);
    WOIIfree(WOII);
    WIIfree(WII);

    printf("4.LOGOUT\n");

    return state_main_num;
}