#include "MainServer.h"

int main() {
    initSocket();

    SOCKET serverSock = setupServerSocket();
    struct sockaddr_in server, client;
    socklen_t clientSize = sizeof(client);

    printf("서버가 포트 %d에서 대기 중입니다...\n", PORT);
    DBO("Users");

    while (1) {  // 계속 클라이언트 접속 기다림
        struct sockaddr_in cliAddr;
        socklen_t cliSize = sizeof(cliAddr);

        SOCKET clientSock = accept(serverSock, (struct sockaddr*)&cliAddr, &cliSize);
        if (clientSock < 0) {
            printf("클라이언트 accept 실패!\n");
            continue;
        }

        printf("클라이언트 접속!\n");
        handleClient(clientSock);
        CLOSESOCKET(clientSock);  // 클라이언트 처리 완료 후 연결 닫음

        printf("클라이언트 연결 종료, 다음 연결 대기...\n\n");
    }

    DBC();    
    CLOSESOCKET(serverSock);
    cleanupSocket();
    return 0;
}

void initSocket() {
    #ifdef _WIN32
        WSADATA wsa;
        WSAStartup(MAKEWORD(2, 2), &wsa);
    #endif
}

void cleanupSocket() {
    #ifdef _WIN32
        WSACleanup();
    #endif
}

int setupServerSocket() {
    int sock = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in servAddr = {0};
    servAddr.sin_family = AF_INET;
    servAddr.sin_port = htons(PORT);
    servAddr.sin_addr.s_addr = INADDR_ANY;

    bind(sock, (struct sockaddr*)&servAddr, sizeof(servAddr));
    listen(sock, 5);
    return sock;
}

void handleClient(SOCKET clientSock) {
    char data[BUF_SIZE];
    char response[BUF_SIZE];
    int len;
    char cmd[16];

    while ((len = recv(clientSock, data, BUF_SIZE - 1, 0)) > 0) {
        data[len] = '\0';
        printf("[요청] %s\n", data);

        sscanf(data, "%[^/]", cmd);

        if (strcmp(cmd, "SIGNUP") == 0) {
            handSignup(clientSock, data);
        } 
        // 로그인 처리
        else if (strcmp(cmd, "LOGIN") == 0) {
            handLogin(clientSock, data);
        } 
        // 식단 입력
        else if (strcmp(cmd, "INPUT_MEAL") == 0) {
            handInputMeal(clientSock, data);
        } 
        // 운동 입력
        else if (strcmp(cmd, "INPUT_WORKOUT") == 0) {
            handInputWorkOut(clientSock, data);
        } 
        // 체중 입력
        else if (strcmp(cmd, "INPUT_WEIGHT") == 0) {
            handInputWeight(clientSock, data);
        } 
        // 날짜별 기록 조회
        else if (strcmp(cmd, "GET_RECORD") == 0) {
            handGetRecord(clientSock, data);
        } 
        // 감량 진행률 계산
        else if (strcmp(cmd, "CHECK_PROGRESS") == 0) {
            handCheckProgress(clientSock, data);
        } 
        // 피드백 추천
        else if (strcmp(cmd, "FEEDBACK") == 0) {
            handFeedBack(clientSock, data);
        } 
        // 로그아웃 처리
        else if (strcmp(cmd, "LOGOUT") == 0) {
            handLogOut(data);
        } 
        // 회원 탈퇴 처리
        else if (strcmp(cmd, "DELETE_ID") == 0) {
            handDeleteID(data);
        }
        else {
            sprintf(response, "[오류] 알 수 없는 명령어");
        }

        // processRequest(clientSock, data, response);
        send(clientSock, response, strlen(response), 0);
    }   
}

void handSignup(SOCKET clientSock, char *data) {
    UserSignupInfo *USI = USImalloc();
    sscanf(
        data, 
        "SIGNUP/%[^/]/%[^/]/%[^/]/%d/%f/%f/%f",
        USI->id, USI->pw, USI->gender, &USI->age,
        &USI->height, &USI->exerciseWeight, &USI->goalWeight
    );

    printf("-> %s %s %s %d %f %f %f\n", USI->id, USI->pw, USI->gender, USI->age, USI->height, USI->exerciseWeight, USI->goalWeight);

    if (userExists(USI->id)) {
        sprintf(data, "[실패] 이미 존재하는 ID입니다->");
    } 
    else {
        signupUser(USI);
        sprintf(data, "[성공] 회원가입 완료");
    }
    
    send(clientSock, data, strlen(data), 0);

    USIfree(USI);
}

void handLogin(SOCKET clientSock, char *data) {
    UserSignupInfo *USI = USImalloc();
    sscanf(data, "LOGIN/%[^/]/%s", USI->id, USI->pw);
    
    if (loginUser(USI->id, USI->pw)) {
        sprintf(data, "[성공] 로그인 성공");
    } 
    else {
        sprintf(data, "[실패] 로그인 실패");
    }

    send(clientSock, data, strlen(data), 0);

    USIfree(USI);
}

void handInputMeal(SOCKET clientSock, char *data) {
    MealInputInfo *MII = MIImalloc();
    sscanf(
        data, 
        "INPUT_MEAL/%[^/]/%[^/]/%[^/]/%f", 
        MII->userId, MII->dateTime, MII->foodName, &MII->gram
    );

    printf("식단 입력 치리 -> %s %s %s %.1f\n", MII->userId, MII->dateTime, MII->foodName, MII->gram);
    insertMeal(MII);

    MIIfree(MII);
}

void handInputWorkOut(SOCKET clientSock, char *data) {
    WorkOutInputInfo *WOII = WOIImalloc();
    float met;

    sscanf(
        data,
        "INPUT_WORKOUT/%[^/]/%[^/]/%[^/]/%f",
        WOII->userId, WOII->dateTime, WOII->exerciseName, &WOII->minutes
    );

    printf("운동 입력 치리 -> %s %s %s %.1f\n", WOII->userId ,WOII->dateTime, WOII->exerciseName, WOII->minutes);

    if (needConvert(CSV_FILE, DB_FILE)) {
        convertCSVtoDB();
    } 
    else {
        printf("최신화 불필요, 기존 DB 사용!\n");
    }

    met = inputWorkoutAndCalc(WOII->exerciseName);

    if (met != -1) {
        sprintf(data, "[성공] 운동 검사 성공");
        
        WOII->kcal = METM(met, WOII->minutes, selectWeight(WOII->userId));
        // sprintf(data, "[실패] 체중 조회 실패");
    }
    else {
        sprintf(data, "[실패] 검사 실패");
    }

    insertWorkout(WOII);
    
    send(clientSock, data, strlen(data), 0);

    WOIIfree(WOII);
}

void handInputWeight(SOCKET clientSock, char *data) {
    WeightInputInfo *WII = WIImalloc();
    sscanf(
        data,
        "INPUT_WEIGHT/%[^/]/%[^/]/%f",
        WII->userId, WII->date, &WII->weight
    );

    printf("체중 입력 치리 -> %s %s %.1f\n", WII->userId, WII->date, WII->weight);
    insertWeight(WII);

    WIIfree(WII);
}

void handGetRecord(SOCKET clientSock, char *data) {
    char id[ID_SIZE], date[11], *rds;
    printf("날짜별 기록 조회\n");

    sscanf(data, "GET_RECORD/%[^/]/%s", id, date);

    rds = viewRecordsByDate(id, date);
    send(clientSock, rds, strlen(rds), 0);
    // printf("MS : %s\n", rds);
}

void handCheckProgress(SOCKET clientSock, char *data) {
    char id[ID_SIZE], *cwlpstr;
    
    printf("감량 진행률 계산\n");

    sscanf(data, "CHECK_PROGRESS/%s", id);

    cwlpstr = checkWeightLossProgress(id);
    send(clientSock, cwlpstr, strlen(cwlpstr), 0);
    
    // printf("MS : %s\n", cwlpstr);
}

void handFeedBack(SOCKET clientSock, char *data) {
    printf("피드백 추천\n");

}

void handLogOut(char *data) {
    char id[ID_SIZE];
    sscanf(data, "LOGOUT/%s", id);
    printf("%s 님이 로그아웃 처리 되었습니다.\n", id);
}

void handDeleteID(char *data) {
    char id[ID_SIZE];
    // printf("회원 탈퇴 처리 해당 사용자 DB 삭제\n");
    sscanf(data, "DELETE_ID/%s", id);

    printf("회원 탈퇴 처리 -> %s\n", id);
    deleteUserData(id);
}

/* void processRequest(SOCKET clientSock, char *request, char *response) {
    char cmd[16];
    float met;
    UserSignupInfo *USI = USImalloc();
    MealInputInfo *MII = MIImalloc();
    WorkOutInputInfo *WOII = WOIImalloc();
    WeightInputInfo *WII = WIImalloc();

    sscanf(request, "%[^/]", cmd);

    // 회원가입 처리
    if (strcmp(cmd, "SIGNUP") == 0) {
        sscanf(
            request, 
            "SIGNUP/%[^/]/%[^/]/%[^/]/%d/%f/%f/%f",
            USI->id, USI->pw, USI->gender, &USI->age,
           &USI->height, &USI->exerciseWeight, &USI->goalWeight
        );

        printf("-> %s %s %s %d %f %f %f\n", USI->id, USI->pw, USI->gender, USI->age, USI->height, USI->exerciseWeight, USI->goalWeight);

        if (userExists(USI->id)) {
            sprintf(response, "[실패] 이미 존재하는 ID입니다->");
        } 
        else {
            signupUser(USI);
            sprintf(response, "[성공] 회원가입 완료");
        }

        USIfree(USI);
    } 

    // 로그인 처리
    else if (strcmp(cmd, "LOGIN") == 0) {
        sscanf(
            request, 
            "LOGIN/%[^/]/%s", 
            USI->id, USI->pw
        );
        
        if (loginUser(USI->id, USI->pw)) {
            sprintf(response, "[성공] 로그인 성공");
        } 
        else {
            sprintf(response, "[실패] 로그인 실패");
        }
        USIfree(USI);
    } 


    // 식단 입력
    else if (strcmp(cmd, "INPUT_MEAL") == 0) {
        sscanf(
            request, 
            "INPUT_MEAL/%[^/]/%[^/]/%[^/]/%f", 
            MII->userId, MII->dateTime, MII->foodName, &MII->gram
        );

        printf("식단 입력 치리 -> %s %s %s %.1f\n", MII->userId, MII->dateTime, MII->foodName, MII->gram);
        insertMeal(MII);

        MIIfree(MII);
    } 
    // 운동 입력
    else if (strcmp(cmd, "INPUT_WORKOUT") == 0) {
        sscanf(
            request,
            "INPUT_WORKOUT/%[^/]/%[^/]/%[^/]/%f",
            WOII->userId, WOII->dateTime, WOII->exerciseName, &WOII->minutes
        );

        printf("운동 입력 치리 -> %s %s %s %.1f\n", WOII->userId ,WOII->dateTime, WOII->exerciseName, WOII->minutes);

        if (needConvert(CSV_FILE, DB_FILE)) {
            convertCSVtoDB();
        } 
        else {
            printf("최신화 불필요, 기존 DB 사용!\n");
        }

        met = inputWorkoutAndCalc(WOII->exerciseName);

        if (met != -1) {
            sprintf(response, "[성공] 운동 검사 성공");
            
            WOII->kcal = METM(met, WOII->minutes, selectWeight(WOII->userId));
            // sprintf(response, "[실패] 체중 조회 실패");
        }
        else {
            sprintf(response, "[실패] 검사 실패");
        }

        insertWorkout(WOII);

        WOIIfree(WOII);
    } 
    // 체중 입력
    else if (strcmp(cmd, "INPUT_WEIGHT") == 0) {
        sscanf(
            request,
            "INPUT_WEIGHT/%[^/]/%[^/]/%f",
            WII->userId, WII->date, &WII->weight
        );

        printf("체중 입력 치리 -> %s %s %.1f\n", WII->userId, WII->date, WII->weight);
        insertWeight(WII);

        WIIfree(WII);
    } 
    

    // 날짜별 기록 조회
    else if (strcmp(cmd, "GET_RECORD") == 0) {
        char id[ID_SIZE], date[11], *rds;
        
        printf("날짜별 기록 조회\n");

        sscanf(request, "GET_RECORD/%[^/]/%s", id, date);

        rds = viewRecordsByDate(id, date);
        send(clientSock, rds, strlen(rds), 0);
        // printf("MS : %s\n", rds);
    } 

    // 피드백 추천
    else if (strcmp(cmd, "FEEDBACK") == 0) {
        printf("피드백 추천\n");
    } 
    

    // 감량 진행률 계산
    else if (strcmp(cmd, "CHECK_PROGRESS") == 0) {
        char id[ID_SIZE], *cwlpstr;
        
        printf("감량 진행률 계산\n");

        sscanf(request, "CHECK_PROGRESS/%s", id);

        cwlpstr = checkWeightLossProgress(id);
        send(clientSock, cwlpstr, strlen(cwlpstr), 0);
        printf("MS : %s\n", cwlpstr);
        
    } 
    // 로그아웃 처리
    else if (strcmp(cmd, "LOGOUT") == 0) {
        char id[ID_SIZE];
        sscanf(request, "LOGOUT/%s", id);
        printf("%s 님이 로그아웃 처리 되었습니다.\n", id);
    } 
    // 회원 탈퇴 처리
    else if (strcmp(cmd, "DELETE_ID") == 0) {
        char id[ID_SIZE];
        // printf("회원 탈퇴 처리 해당 사용자 DB 삭제\n");
        sscanf(request, "DELETE_ID/%s", id);

        printf("회원 탈퇴 처리 -> %s\n", id);
        deleteUserData(id);
    }
    
    else {
        sprintf(response, "[오류] 알 수 없는 명령어");
    }
} */