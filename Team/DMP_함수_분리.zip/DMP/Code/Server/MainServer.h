#ifndef _MS_
#define _MS_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "DBM.h"
#include "InputInfo.h"
#include "exerciseDB.h"

#ifdef _WIN32
    #include <winsock2.h>
    #pragma comment(lib, "ws2_32.lib")
    typedef int socklen_t;
    #define CLOSESOCKET closesocket
#else
    #include <unistd.h>
    #include <arpa/inet.h>
    #include <sys/socket.h>
    #define SOCKET int
    #define CLOSESOCKET close
#endif

void handleClient(SOCKET clientSock);
void processRequest(SOCKET clientSock, char *request, char *response);

// 초기화 및 종료
void initSocket();
void cleanupSocket();
int setupServerSocket();

// 메뉴별 처리 함수
void handSignup(SOCKET clientSock, char *data);
void handLogin(SOCKET clientSock, char *data);
void handInputMeal(SOCKET clientSock, char *data);
void handInputWorkOut(SOCKET clientSock, char *data);
void handInputWeight(SOCKET clientSock, char *data);
void handGetRecord(SOCKET clientSock, char *data);
void handCheckProgress(SOCKET clientSock, char *data);
void handFeedBack(SOCKET clientSock, char *data);
void handLogOut(char *data);
void handDeleteID(char *data);

#endif